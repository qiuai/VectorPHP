<?php

if (!isset($_SESSION)) session_start();

require 'core/load.php';